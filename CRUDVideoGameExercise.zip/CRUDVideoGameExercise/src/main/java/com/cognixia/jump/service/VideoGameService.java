package com.cognixia.jump.service;

public class VideoGameService {

}
