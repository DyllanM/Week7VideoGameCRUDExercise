package com.cognixia.jump.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognixia.jump.model.VideoGame;
import com.cognixia.jump.repository.VideoGameRepository;

@RequestMapping("/api")
@RestController
public class VideoGameController {
	
	@Autowired
	VideoGameRepository repo;
	
	@Value("${my.custom.property}")
	String custom;
	
	@GetMapping("/custom")
	public String showCustomProperty()
	{
		return custom;
	}
	
	@GetMapping("/games")
	public ResponseEntity<Object> getAllVideoGames()
	{
		List<VideoGame> allGames = repo.findAll();
		
		if (allGames.isEmpty())
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("There are no games in the DB");
		
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(allGames);
	}
	
	@GetMapping("/games/{id}")
	public ResponseEntity<Object> getGameById(@PathVariable Long id)
	{
		Optional<VideoGame> foundGame = repo.findById(id);
		
		if (foundGame.isPresent())
		{
			return ResponseEntity.status(HttpStatus.OK).body(foundGame.get());
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Game not found by id " + id);
	 
	}
	
	@GetMapping("/games/name/{name}")
	public ResponseEntity<Object> getGameByName(@PathVariable String name)
	{
		List<VideoGame> validGames = repo.findByName(name);
		
		if (!validGames.isEmpty())
		{
			return ResponseEntity.status(HttpStatus.OK).body(validGames);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Game not found by name " + name);
	 
	}
	
	@GetMapping("/games/genre/{genre}")
	public ResponseEntity<Object> getGameByGenre(@PathVariable String genre)
	{
		List<VideoGame> validGames = repo.findByGenre(genre);
		
		if (!validGames.isEmpty())
		{
			return ResponseEntity.status(HttpStatus.OK).body(validGames);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Game not found by genre " + genre);
	 
	}
	
	@GetMapping("/games/console/{console}")
	public ResponseEntity<Object> getGameByConsole(@PathVariable String console)
	{
		List<VideoGame> validGames = repo.findByConsole(console);
		
		if (!validGames.isEmpty())
		{
			return ResponseEntity.status(HttpStatus.OK).body(validGames);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Game not found by console " + console);
	 
	}
	
	@GetMapping("/games/price/{price}")
	public ResponseEntity<Object> getGameByPrice(@PathVariable float price)
	{
		List<VideoGame> validGames = repo.findByPrice(price);
		
		if (!validGames.isEmpty())
		{
			return ResponseEntity.status(HttpStatus.OK).body(validGames);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Game not found by price " + price);
	 
	}
	
	
	//@PostMapping(value = "/addgame", consumes = {"application/xml","application/json"})
	@PostMapping("/addgame")
	public ResponseEntity<Object> addGame(@RequestBody VideoGame newGame)
	{
		VideoGame addedGame = repo.save(newGame);
		
		return ResponseEntity.status(HttpStatus.OK).body(addedGame.toString() + " created");
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> updateGame(@RequestBody VideoGame videogame)
	{
		Optional<VideoGame> found = repo.findById(videogame.getId());
		
		if (found.isPresent())
		{
			repo.save(videogame);
			return ResponseEntity.status(HttpStatus.OK).body("Game Updated: " + videogame.toString());
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Game not found for update");
		
	}
	
	@DeleteMapping("/delete/games/{id}")
	public ResponseEntity<Object> deleteGameById(@PathVariable Long id) {
		
		//find if the data exists and grab it
		Optional<VideoGame> found = repo.findById(id);
		
		//if exists, delete with repo, return response
		if (found.isPresent()) {
			repo.deleteById(id);
			return ResponseEntity.status(HttpStatus.OK).body("Video Game: " + found.get().toString() + " deleted.");
		}
		
		//not exists, return response that not found
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Video Game: " + id + " not found, not deleted.");
		
	}

}
