package com.cognixia.jump.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognixia.jump.model.VideoGame;

public interface VideoGameRepository extends JpaRepository<VideoGame, Long>{

	List<VideoGame> findByName(String name);
	
	List<VideoGame> findByPrice(float price);
	
	List<VideoGame> findByGenre(String genre);
	
	List<VideoGame> findByConsole(String console);
	
}
