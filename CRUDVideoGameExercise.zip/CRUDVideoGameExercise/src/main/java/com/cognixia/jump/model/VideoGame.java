package com.cognixia.jump.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class VideoGame implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "price")
	private float price;
	
	@Column(name = "genre")
	private String genre;
	
	@Column(name = "console")
	private String console;
	
	
	public VideoGame()
	{
		this(-1L, "N/A", -1.0f, "N/A", "N/A");
	}
	
	public VideoGame(Long id, String name, float price, String genre, String console)
	{
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.genre = genre;
		this.console = console;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getConsole() {
		return console;
	}

	public void setConsole(String console) {
		this.console = console;
	}

	@Override
	public String toString() {
		return "VideoGame [id=" + id + ", name=" + name + ", price=" + price + ", genre=" + genre + ", console="
				+ console + "]";
	}
	
	
	
}
